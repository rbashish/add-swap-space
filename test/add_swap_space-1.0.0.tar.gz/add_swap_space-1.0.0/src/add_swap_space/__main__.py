from add_swap_space.add_swap_space import add_swap_space

if __name__ == "__main__":
    add_swap_space()